'use client';

import { useState, useEffect } from 'react';
import { useTransactions } from '../contexts/TransactionContext';
import { Transaction } from '../types/transaction';

interface TransactionModalProps {
  transaction?: Transaction;
  isOpen: boolean;
  onClose: () => void;
}

export default function TransactionModal({ transaction, isOpen, onClose }: TransactionModalProps) {
  const { categories, addTransaction, updateTransaction } = useTransactions();
  const [date, setDate] = useState(transaction?.date || new Date().toISOString().split('T')[0]);
  const [description, setDescription] = useState(transaction?.description || '');
  const [categoryId, setCategoryId] = useState(transaction?.category || '');
  const [amount, setAmount] = useState(transaction?.amount.toString() || '');
  const [type, setType] = useState<'income' | 'expense'>(transaction?.type || 'expense');

  // トランザクションが変更されたときにフォームを更新
  useEffect(() => {
    if (transaction) {
      setDate(transaction.date);
      setDescription(transaction.description);
      setCategoryId(transaction.category);
      setAmount(transaction.amount.toString());
      setType(transaction.type);
    } else {
      // 新規作成の場合は初期値を設定
      setDate(new Date().toISOString().split('T')[0]);
      setDescription('');
      setCategoryId('');
      setAmount('');
      setType('expense');
    }
  }, [transaction]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!categoryId || !amount) {
      alert('カテゴリと金額は必須です。');
      return;
    }
    
    const numericAmount = parseFloat(amount);
    if (isNaN(numericAmount)) {
      alert('金額は数値で入力してください。');
      return;
    }
    
    const transactionData = {
      date,
      description,
      category: categoryId,
      amount: type === 'expense' ? -Math.abs(numericAmount) : Math.abs(numericAmount),
      type,
    };
    
    if (transaction) {
      // 既存のトランザクションを更新
      updateTransaction(transaction.id, transactionData);
    } else {
      // 新しいトランザクションを追加
      addTransaction(transactionData);
    }
    
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-md">
        <div className="p-6">
          <h2 className="text-2xl font-bold mb-4">
            {transaction ? 'トランザクションを編集' : '新しいトランザクション'}
          </h2>
          
          <form onSubmit={handleSubmit}>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  日付
                </label>
                <input
                  type="date"
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  required
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  内容
                </label>
                <input
                  type="text"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  placeholder="内容を入力"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  カテゴリ
                </label>
                <select
                  value={categoryId}
                  onChange={(e) => setCategoryId(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  required
                >
                  <option value="">カテゴリを選択</option>
                  {categories
                    .filter(cat => cat.type === type)
                    .map(category => (
                      <option key={category.id} value={category.id}>
                        {category.name}
                      </option>
                    ))}
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  金額
                </label>
                <input
                  type="number"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  placeholder="金額を入力"
                  required
                  min="0"
                  step="0.01"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  種類
                </label>
                <div className="flex space-x-4">
                  <label className="inline-flex items-center">
                    <input
                      type="radio"
                      checked={type === 'income'}
                      onChange={() => setType('income')}
                      className="text-indigo-600 focus:ring-indigo-500"
                    />
                    <span className="ml-2">収入</span>
                  </label>
                  <label className="inline-flex items-center">
                    <input
                      type="radio"
                      checked={type === 'expense'}
                      onChange={() => setType('expense')}
                      className="text-indigo-600 focus:ring-indigo-500"
                    />
                    <span className="ml-2">支出</span>
                  </label>
                </div>
              </div>
            </div>
            
            <div className="mt-6 flex justify-end space-x-3">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 rounded-md hover:bg-gray-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
              >
                キャンセル
              </button>
              <button
                type="submit"
                className="px-4 py-2 text-sm font-medium text-white bg-indigo-600 rounded-md hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
              >
                {transaction ? '更新' : '追加'}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}