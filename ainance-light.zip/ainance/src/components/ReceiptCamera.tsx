"use client";

import { useState, useRef, useEffect } from 'react';

export default function ReceiptCamera() {
  const [isCameraActive, setIsCameraActive] = useState(false);
  const [capturedImage, setCapturedImage] = useState<string | null>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  // カメラの起動
  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ 
        video: { facingMode: 'environment' } 
      });
      
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        setIsCameraActive(true);
      }
    } catch (err) {
      console.error('カメラの起動に失敗しました:', err);
      alert('カメラの起動に失敗しました。権限を確認してください。');
    }
  };

  // カメラの停止
  const stopCamera = () => {
    if (videoRef.current && videoRef.current.srcObject) {
      const stream = videoRef.current.srcObject as MediaStream;
      const tracks = stream.getTracks();
      
      tracks.forEach(track => track.stop());
      videoRef.current.srcObject = null;
      setIsCameraActive(false);
    }
  };

  // 写真の撮影
  const captureImage = () => {
    if (videoRef.current && canvasRef.current) {
      const context = canvasRef.current.getContext('2d');
      if (context) {
        canvasRef.current.width = videoRef.current.videoWidth;
        canvasRef.current.height = videoRef.current.videoHeight;
        context.drawImage(videoRef.current, 0, 0);
        const imageData = canvasRef.current.toDataURL('image/png');
        setCapturedImage(imageData);
        stopCamera();
      }
    }
  };

  // 再撮影
  const retakeImage = () => {
    setCapturedImage(null);
    startCamera();
  };

  // 画像の処理（OCR）
  const processImage = () => {
    if (capturedImage) {
      // ここでOCR処理を実行
      alert('OCR処理を実行します。実際のアプリではここでTesseract.jsなどのOCRエンジンを使用します。');
      console.log('Processing image for OCR:', capturedImage);
    }
  };

  // コンポーネントのクリーンアップ
  useEffect(() => {
    return () => {
      stopCamera();
    };
  }, []);

  return (
    <div className="w-full max-w-2xl mx-auto">
      {!capturedImage ? (
        <div className="relative">
          <video 
            ref={videoRef} 
            autoPlay 
            playsInline 
            className="w-full h-auto rounded-lg shadow-md"
          />
          <canvas ref={canvasRef} className="hidden" />
          
          {isCameraActive && (
            <div className="absolute bottom-4 left-0 right-0 flex justify-center space-x-4">
              <button 
                onClick={captureImage}
                className="bg-white rounded-full p-4 shadow-lg hover:bg-gray-100 transition"
              >
                <div className="w-12 h-12 rounded-full bg-red-500"></div>
              </button>
              <button 
                onClick={stopCamera}
                className="bg-white rounded-full p-4 shadow-lg hover:bg-gray-100 transition"
              >
                <div className="w-12 h-12 rounded-full bg-gray-500"></div>
              </button>
            </div>
          )}
        </div>
      ) : (
        <div className="space-y-4">
          <img 
            src={capturedImage} 
            alt="Captured receipt" 
            className="w-full h-auto rounded-lg shadow-md"
          />
          <div className="flex justify-center space-x-4">
            <button 
              onClick={retakeImage}
              className="bg-gray-500 text-white px-6 py-2 rounded-lg hover:bg-gray-600 transition"
            >
              再撮影
            </button>
            <button 
              onClick={processImage}
              className="bg-indigo-600 text-white px-6 py-2 rounded-lg hover:bg-indigo-700 transition"
            >
              OCR処理
            </button>
          </div>
        </div>
      )}
      
      {!isCameraActive && !capturedImage && (
        <div className="text-center">
          <button 
            onClick={startCamera}
            className="bg-indigo-600 text-white px-6 py-3 rounded-lg hover:bg-indigo-700 transition"
          >
            カメラを起動
          </button>
        </div>
      )}
    </div>
  );
}
