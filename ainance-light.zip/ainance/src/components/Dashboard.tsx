'use client';

import { useState, useEffect } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { useTransactions } from '../contexts/TransactionContext';
import TransactionList from './TransactionList';

// グラフの色
const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884D8'];

export default function Dashboard() {
  const { transactions, categories } = useTransactions();
  const [income, setIncome] = useState(0);
  const [expense, setExpense] = useState(0);
  const [balance, setBalance] = useState(0);
  const [monthlyData, setMonthlyData] = useState<any[]>([]);
  const [categoryData, setCategoryData] = useState<any[]>([]);

  // データの計算
  useEffect(() => {
    // 収入、支出、収支差額の計算
    const totalIncome = transactions
      .filter(t => t.amount > 0)
      .reduce((sum, transaction) => sum + transaction.amount, 0);
    
    const totalExpense = transactions
      .filter(t => t.amount < 0)
      .reduce((sum, transaction) => sum + Math.abs(transaction.amount), 0);
    
    setIncome(totalIncome);
    setExpense(totalExpense);
    setBalance(totalIncome - totalExpense);
    
    // 月ごとのデータを集計
    const monthlyMap: Record<string, { income: number; expense: number }> = {};
    
    transactions.forEach(transaction => {
      const month = transaction.date.substring(0, 7); // YYYY-MM
      if (!monthlyMap[month]) {
        monthlyMap[month] = { income: 0, expense: 0 };
      }
      
      if (transaction.amount > 0) {
        monthlyMap[month].income += transaction.amount;
      } else {
        monthlyMap[month].expense += Math.abs(transaction.amount);
      }
    });
    
    const monthlyArray = Object.entries(monthlyMap)
      .map(([name, values]) => ({ name, ...values }))
      .sort((a, b) => a.name.localeCompare(b.name));
    
    setMonthlyData(monthlyArray);
    
    // カテゴリごとの支出を集計
    const categoryMap: Record<string, number> = {};
    
    transactions
      .filter(t => t.amount < 0)
      .forEach(transaction => {
        const categoryName = categories.find(c => c.id === transaction.category)?.name || '未分類';
        if (!categoryMap[categoryName]) {
          categoryMap[categoryName] = 0;
        }
        categoryMap[categoryName] += Math.abs(transaction.amount);
      });
    
    const categoryArray = Object.entries(categoryMap)
      .map(([name, value]) => ({ name, value }))
      .sort((a, b) => b.value - a.value);
    
    setCategoryData(categoryArray);
  }, [transactions, categories]);

  return (
    <div className="space-y-8">
      {/* メトリックカード */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white rounded-xl shadow-md p-6">
          <h3 className="text-lg font-semibold text-gray-500 mb-2">総収入</h3>
          <p className="text-3xl font-bold text-green-500">¥{income.toLocaleString()}</p>
        </div>
        <div className="bg-white rounded-xl shadow-md p-6">
          <h3 className="text-lg font-semibold text-gray-500 mb-2">総支出</h3>
          <p className="text-3xl font-bold text-red-500">¥{expense.toLocaleString()}</p>
        </div>
        <div className="bg-white rounded-xl shadow-md p-6">
          <h3 className="text-lg font-semibold text-gray-500 mb-2">収支差額</h3>
          <p className="text-3xl font-bold text-blue-500">¥{balance.toLocaleString()}</p>
        </div>
      </div>

      {/* グラフセクション */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* 収支トレンドチャート */}
        <div className="bg-white rounded-xl shadow-md p-6">
          <h3 className="text-xl font-semibold mb-4">収支トレンド</h3>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                data={monthlyData}
                margin={{
                  top: 5,
                  right: 30,
                  left: 20,
                  bottom: 5,
                }}
              >
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip 
                  formatter={(value) => [`¥${Number(value).toLocaleString()}`, '']}
                  labelFormatter={(label) => `${label}`}
                />
                <Legend />
                <Bar dataKey="income" fill="#10B981" name="収入" />
                <Bar dataKey="expense" fill="#EF4444" name="支出" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* 支出カテゴリチャート */}
        <div className="bg-white rounded-xl shadow-md p-6">
          <h3 className="text-xl font-semibold mb-4">支出カテゴリ</h3>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={categoryData}
                  cx="50%"
                  cy="50%"
                  labelLine={true}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                  label={({ name, percent }) => `${name} ${(percent as number * 100).toFixed(0)}%`}
                >
                  {categoryData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip formatter={(value) => [`¥${Number(value).toLocaleString()}`, '']} />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* トランザクション一覧 */}
      <TransactionList />
    </div>
  );
}