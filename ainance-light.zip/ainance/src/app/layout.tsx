import type { Metadata } from "next";
import { Inter } from "next/font/google";
import "./globals.css";
import { TransactionProvider } from "../contexts/TransactionContext";

const inter = Inter({ subsets: ["latin"] });

export const metadata: Metadata = {
  title: 'AInance - AI会計アプリ',
  description: 'AIを活用したスマートな会計管理アプリ',
  // PWA対応のためのメタデータ
  manifest: '/manifest.json',
  themeColor: '#3b82f6',
  icons: {
    icon: '/icon-192x192.png',
    apple: '/icon-192x192.png',
    shortcut: '/icon-192x192.png',
  },
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="ja">
      <body className={inter.className}>
        <TransactionProvider>
          {children}
        </TransactionProvider>
      </body>
    </html>
  );
}