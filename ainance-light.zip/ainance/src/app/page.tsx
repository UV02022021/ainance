"use client"

import { useState } from 'react';
import ReceiptCamera from '../components/ReceiptCamera';
import VoiceInput from '../components/VoiceInput';
import Dashboard from '../components/Dashboard';

export default function Home() {
  const [activeTab, setActiveTab] = useState<'dashboard' | 'camera' | 'voice'>('dashboard');

  return (
    <div className="min-h-screen bg-gray-100">
      {/* ヘッダー */}
      <header className="bg-indigo-600 text-white shadow-md">
        <div className="container mx-auto px-4 py-4">
          <div className="flex justify-between items-center">
            <h1 className="text-xl font-bold">AInance</h1>
            <div className="flex space-x-2">
              <button 
                onClick={() => setActiveTab('dashboard')}
                className={`px-3 py-2 rounded-lg ${activeTab === 'dashboard' ? 'bg-indigo-700' : 'bg-indigo-500'}`}
              >
                ダッシュボード
              </button>
              <button 
                onClick={() => setActiveTab('camera')}
                className={`px-3 py-2 rounded-lg ${activeTab === 'camera' ? 'bg-indigo-700' : 'bg-indigo-500'}`}
              >
                レシート読み取り
              </button>
              <button 
                onClick={() => setActiveTab('voice')}
                className={`px-3 py-2 rounded-lg ${activeTab === 'voice' ? 'bg-indigo-700' : 'bg-indigo-500'}`}
              >
                音声入力
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* メインコンテンツ */}
      <main className="container mx-auto px-4 py-8">
        {activeTab === 'dashboard' && <Dashboard />}
        {activeTab === 'camera' && <ReceiptCamera />}
        {activeTab === 'voice' && <VoiceInput />}
      </main>

      {/* フッター */}
      <footer className="bg-gray-800 text-white py-6">
        <div className="container mx-auto px-4 text-center">
          <p>© 2023 AInance - AI会計アプリ</p>
        </div>
      </footer>
    </div>
  )
}