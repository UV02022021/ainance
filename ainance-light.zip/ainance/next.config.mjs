import { InjectManifest } from 'workbox-webpack-plugin';

/** @type {import('next').NextConfig} */
const nextConfig = {
  experimental: {
    serverActions: {
      enabled: true,
    },
  },
  // PWA対応のための設定
  webpack: (config) => {
    config.module.rules.push({
      test: /\.svg$/,
      use: ['@svgr/webpack'],
    });
    
    // Workboxプラグインの設定
    config.plugins.push(
      new InjectManifest({
        swSrc: './public/sw.js',
        swDest: 'sw.js',
        exclude: [/manifest\.json$/]
      })
    );
    
    return config;
  },
}

export default nextConfig